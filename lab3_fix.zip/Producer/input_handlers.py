import csv
import json
from typing import List, Tuple, Any, Optional


def _coerce_scalar(value: Any) -> Any:
    if isinstance(value, str):
        s = value.strip()
        if s == "":
            return ""
        if s.isdigit() or (s.startswith("-") and s[1:].isdigit()):
            try:
                return int(s)
            except Exception:
                pass
        s_float = s.replace(",", ".")
        try:
            if any(ch.isalpha() for ch in s_float):
                return s
            if "-" in s_float[1:]:
                return s
            return float(s_float)
        except Exception:
            return s
    return value


def _normalize_columns(columns: List[str]) -> List[str]:
    return [(c or "").strip() for c in columns]


def _normalize_rows(rows: List[List[Any]]) -> List[List[Any]]:
    norm: List[List[Any]] = []
    for row in rows:
        if row is None:
            continue
        norm.append([_coerce_scalar(v) for v in row])
    return norm


def manual_input() -> Tuple[str, List[str], List[List[Any]]]:
    table_name = input("Введите имя таблицы: ").strip()
    columns = input("Введите названия столбцов через запятую: ").split(",")
    columns = _normalize_columns(columns)

    rows: List[List[Any]] = []
    print(
        "Введите строки данных:\n"
        " - '///' — разделитель столбцов\n"
        " - пустая строка — завершить ввод"
    )

    while True:
        line = input()
        if not line:
            break
        parts = [value.strip() for value in line.split("///")]
        rows.append([_coerce_scalar(v) for v in parts])

    return table_name, columns, rows


def read_csv_file(path: str) -> Tuple[Optional[str], List[str], List[List[Any]]]:
    with open(path, newline="", encoding="utf-8") as file:
        reader = csv.reader(file)
        data = [row for row in reader if row and any(cell.strip() for cell in row)]

    if len(data) < 2:
        raise ValueError("CSV файл пуст или не содержит данных")

    columns = _normalize_columns(data[0])
    rows_raw = data[1:]
    rows = _normalize_rows([[cell.strip() for cell in row] for row in rows_raw])

    table_name = None
    return table_name, columns, rows


def read_json_file(path: str) -> Tuple[Optional[str], List[str], List[List[Any]]]:
    with open(path, encoding="utf-8") as file:
        data = json.load(file)

    if not isinstance(data, dict):
        raise ValueError("JSON файл имеет неверную структуру (ожидался объект)")

    if "columns" not in data or "rows" not in data:
        raise ValueError("JSON файл имеет неверную структуру (нужны поля columns и rows)")

    columns = _normalize_columns(data["columns"])
    rows = _normalize_rows(data["rows"])
    table_name = data.get("table_name")

    return table_name, columns, rows
