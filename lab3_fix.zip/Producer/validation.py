import re
from typing import List


_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def validate_table_name(name: str) -> str:
    name = (name or "").strip()
    if not name:
        raise ValueError("Имя таблицы не может быть пустым")
    if not _IDENTIFIER_RE.match(name):
        raise ValueError("Некорректное имя таблицы. Допустимы латинские буквы, цифры и '_' (не с цифры)")
    return name


def validate_columns(columns: List[str]) -> List[str]:
    if not columns:
        raise ValueError("Список столбцов пуст")

    cleaned: List[str] = []
    for col in columns:
        col = (col or "").strip()
        if not col:
            raise ValueError("Обнаружено пустое имя столбца")
        if not _IDENTIFIER_RE.match(col):
            raise ValueError(f"Некорректное имя столбца: {col}")
        cleaned.append(col)

    if len(cleaned) != len(set(cleaned)):
        raise ValueError("Названия столбцов должны быть уникальны")

    return cleaned


def validate_rows(rows: List[List], columns_count: int) -> None:
    if rows is None or len(rows) == 0:
        raise ValueError("Отсутствуют данные для вставки")

    for idx, row in enumerate(rows, start=1):
        if row is None:
            raise ValueError(f"Ошибка в строке {idx}: строка равна None")
        if len(row) != columns_count:
            raise ValueError(f"Ошибка в строке {idx}: ожидалось {columns_count} значений, получено {len(row)}")
