import json

try:
    from .config import KAFKA_BOOTSTRAP_SERVERS, KAFKA_TOPIC
except ImportError:
    from config import KAFKA_BOOTSTRAP_SERVERS, KAFKA_TOPIC


def send_message(message: dict) -> None:
    print("\n[Kafka заглушка] Сообщение, которое отправилось бы в Kafka")
    print(f"bootstrap_servers: {KAFKA_BOOTSTRAP_SERVERS}")
    print(f"topic: {KAFKA_TOPIC}")
    print(json.dumps(message, ensure_ascii=False, indent=2))
    print("[Kafka заглушка] Конец сообщения\n")
