try:
    from .input_handlers import manual_input, read_csv_file, read_json_file
    from .validation import validate_table_name, validate_columns, validate_rows
    from .kafka_sender import send_message
except ImportError:
    from input_handlers import manual_input, read_csv_file, read_json_file
    from validation import validate_table_name, validate_columns, validate_rows
    from kafka_sender import send_message


def _ensure_id_first(columns: list[str], rows: list[list]):
    if "id" not in columns:
        print("В столбцах нет 'id' — добавляю 'id' и генерирую значения.")
        columns = ["id"] + columns
        new_rows = []
        for idx, row in enumerate(rows, start=1):
            new_rows.append([idx] + row)
        return columns, new_rows

    if columns[0] != "id":
        id_index = columns.index("id")
        print("Столбец 'id' не первый — перемещаю его в начало.")
        new_columns = ["id"] + [c for c in columns if c != "id"]
        new_rows = []
        for row in rows:
            new_row = [row[id_index]] + [row[i] for i in range(len(row)) if i != id_index]
            new_rows.append(new_row)
        return new_columns, new_rows

    return columns, rows


def process_single_table():
    print("\nВыберите способ ввода данных:")
    print("1 — Ручной ввод")
    print("2 — Загрузка CSV файла")
    print("3 — Загрузка JSON файла")

    choice = input("> ").strip()

    if choice == "1":
        table_name, columns, rows = manual_input()
    elif choice == "2":
        csv_path = input("Введите путь к CSV файлу: ").strip()
        table_name = input("Введите имя таблицы: ").strip()
        _, columns, rows = read_csv_file(csv_path)
    elif choice == "3":
        json_path = input("Введите путь к JSON файлу: ").strip()
        table_name, columns, rows = read_json_file(json_path)
        if not table_name:
            table_name = input("В JSON нет table_name. Введите имя таблицы: ").strip()
    else:
        print("Неверный выбор режима")
        return

    table_name = validate_table_name(table_name)
    columns = validate_columns(columns)
    columns, rows = _ensure_id_first(columns, rows)
    validate_rows(rows, len(columns))

    message = {"table_name": table_name, "columns": columns, "rows": rows}

    send_message(message)
    print(f"Данные для таблицы '{table_name}' подготовлены и выведены через Kafka-заглушку")


def main():
    print("ETL Producer (Kafka-заглушка)")

    while True:
        try:
            process_single_table()
        except Exception as error:
            print("Ошибка:", error)

        answer = input("\nДобавить ещё одну таблицу? (д/н): ").strip().lower()
        if answer not in ("д", "y", "да"):
            break

    print("Работа завершена")


if __name__ == "__main__":
    main()
