#include <iostream>
#include <string>
using namespace std;

class A {
private:
    int s;

public:
    A() {
        s = 0;
        cout << "объект A" << endl;
    }

    void a(int x) {
        s += x;
        cout << "Добавлено число: " << x << ", текущая сумма = " << s << endl;
    }

    void b(int k) {
        s *= k;
        cout << "Сумма умножена на " << k << ", теперь сумма = " << s << endl;
    }

    void c() {
        cout << "Итоговая сумма: " << s << endl;
    }
};

void B(string t) {
    cout << "Анализ строки: " << t << endl;
    int l = 0;

    for (int i = 0; i < t.length(); i++) {
        if (isalpha(t[i])) {
            l++;
        }
    }

    cout << "Количество букв: " << l << endl;
}

int main() {
    A obj;

    for (int i = 1; i <= 5; i++) {
        obj.a(i);
    }

    obj.b(2);
    obj.c();

    B("Hello123!");

    return 0;
}
