class A:
    def __init__(self):
        self.s = 0
        print('объект A')
        print("объект A" ,)
    def a(self, x):
        self.s += x
        print("Добавлено число: " , x , ", текущая сумма = " , self.s ,)
    def b(self, k):
        self.s *= k
        print("Сумма умножена на " , k , ", теперь сумма = " , self.s ,)
    def c(self):
        print("Итоговая сумма: " , self.s ,)

def B(t):
    l = 0
    for i in range(len(t)):
        if t[i].isalpha():
            l += 1
if __name__ == '__main__':
    obj = A()
    for i in range(1, 6):
        obj.a(i)
    obj.b(2)
    obj.c()
    B('Hello123!')