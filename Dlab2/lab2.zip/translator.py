import re

with open("input.cpp", "r", encoding="utf-8") as f:
    cpp = f.readlines()

py = []
in_class = False
main_started = False

for line in cpp:
    original = line.strip()
    
    if (original.startswith("#") or original.startswith("using ") or 
        original == "" or original.startswith("//")):
        continue
    
    if original == "class A {" or original.startswith("class A"):
        py.append("class A:")
        in_class = True
        continue
    
    if in_class and original == "};":
        in_class = False
        py.append("")
        continue
    
    if in_class and "A()" in original:
        py.append("    def __init__(self):")
        py.append("        self.s = 0")
        py.append("        print('объект A')")
        continue
    
    if in_class and "void a(int x)" in original:
        py.append("    def a(self, x):")
        continue
    
    if in_class and "void b(int k)" in original:
        py.append("    def b(self, k):")
        continue
    
    if in_class and "void c()" in original:
        py.append("    def c(self):")
        continue
    
    if in_class and ("s += x" in original or "s += x;" in original):
        py.append("        self.s += x")
        continue
    
    if in_class and ("s *= k" in original or "s *= k;" in original):
        py.append("        self.s *= k")
        continue
    
    if in_class and "cout <<" in original:
        content = original.replace("cout <<", "").replace(";", "")
        content = content.replace("<<", ",")
        content = content.replace("endl", "")
        content = content.replace(" s,", " self.s,")
        content = content.replace(" s ", " self.s ")
        content = content.replace(' s"', ' self.s"')
        content = content.replace(' s,', ' self.s,')
        
        if content.strip().endswith("s"):
            content = content.strip()[:-1] + "self.s"
        
        py.append(f"        print({content.strip()})")
        continue
    
    if "void B(string t)" in original:
        py.append("def B(t):")
        continue
    
    if "cout << \"Анализ строки:\" << t << endl;" in original:
        py.append("    print('Анализ строки:', t)")
        continue
    
    if "int l = 0;" in original:
        py.append("    l = 0")
        continue
    
    if "for (int i = 0; i < t.length(); i++)" in original:
        py.append("    for i in range(len(t)):")
        continue
    
    if "if (isalpha(t[i]))" in original:
        py.append("        if t[i].isalpha():")
        continue
    
    if "l++;" in original:
        py.append("            l += 1")
        continue
    
    if "cout << \"Количество букв:\" << l << endl;" in original:
        py.append("    print('Количество букв:', l)")
        continue
    
    if "int main()" in original:
        py.append("if __name__ == '__main__':")
        main_started = True
        continue
    
    if main_started and "A obj;" in original:
        py.append("    obj = A()")
        continue
    
    if main_started and "for (int i = 1; i <= 5; i++)" in original:
        py.append("    for i in range(1, 6):")
        continue
    
    if main_started and "obj.a(i);" in original:
        py.append("        obj.a(i)")
        continue
    
    if main_started and "obj.b(2);" in original:
        py.append("    obj.b(2)")
        continue
    
    if main_started and "obj.c();" in original:
        py.append("    obj.c()")
        continue
    
    if main_started and "B(\"Hello123!\");" in original:
        py.append("    B('Hello123!')")
        continue
    
    if main_started and "return 0;" in original:
        continue
    
    if (original in ["private:", "public:", "{", "}", "};"] or
        original.endswith("{")):
        continue

final_output = []
for line in py:
    if "print" in line and "self.s" not in line:
        line = line.replace(", s,", ", self.s,")
        line = line.replace(", s)", ", self.s)")
        line = line.replace(" s,", " self.s,")
        line = line.replace(" s)", " self.s)")
    
    final_output.append(line)

with open("output.py", "w", encoding="utf-8") as f:
    f.write("\n".join(final_output))