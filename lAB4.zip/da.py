
"""
Проверка ссылок VesselFinder.
Если по ссылке найдено ровно одно судно —
извлекаются: Название, IMO, MMSI, Тип.
Результат сохраняется в result.xlsx
"""

from __future__ import annotations

import argparse
import re
import time
from dataclasses import dataclass
from typing import Optional, Tuple, List, Dict

import pandas as pd
import requests
from bs4 import BeautifulSoup


VF_HOST = "https://www.vesselfinder.com"


@dataclass
class ShipInfo:
    link: str
    name: str
    imo: str
    mmsi: str
    ship_type: str


def normalize(text: str) -> str:
    return " ".join(text.split()).strip()


def fetch(url: str, timeout: int) -> Tuple[str, str]:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0 Safari/537.36"
        ),
        "Accept-Language": "ru,en;q=0.8",
    }
    r = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
    r.raise_for_status()
    r.encoding = r.encoding or "utf-8"
    return r.url, r.text




def is_vessel_page(html: str) -> bool:
    """
    Надёжнее всего: на карточке судна почти всегда есть таблица параметров.
    Но если класс отличается/обрезано — fallback на наличие IMO+MMSI в тексте.
    """
    soup = BeautifulSoup(html, "html.parser")
    if soup.find("table", class_="aparams"):
        return True

    text = normalize(soup.get_text(" "))
    return bool(re.search(r"\bIMO\b\s*[:#]?\s*\d{7}\b", text)) and bool(
        re.search(r"\bMMSI\b\s*[:#]?\s*\d{9}\b", text)
    )



def extract_vessel_links_from_search(html: str) -> List[str]:
    """
    Берём ссылки ТОЛЬКО из таблицы результатов (строк с судами),
    а не все /vessels/ ссылки на странице.
    """
    soup = BeautifulSoup(html, "html.parser")


    candidates = soup.select('a[href^="/vessels/"], a[href^="/ru/vessels/"]')

    links: List[str] = []
    for a in candidates:
        href = a.get("href", "")
        if not href:
            continue


        in_row = a.find_parent("tr")
        if not in_row:
            continue


        if "?" in href or "#" in href:
            continue

        full = VF_HOST + href
        links.append(full)


    uniq: List[str] = []
    seen = set()
    for l in links:
        if l not in seen:
            seen.add(l)
            uniq.append(l)

    return uniq




def _extract_value_from_tables(soup: BeautifulSoup, label: str) -> str:
    """
    Ищет значение по label в таблицах формата:
    <tr><td>IMO</td><td>1234567</td></tr>
    """
    label_l = label.lower()


    tables = []
    t1 = soup.find("table", class_="aparams")
    if t1:
        tables.append(t1)

    tables.extend(soup.find_all("table"))

    for table in tables:
        for tr in table.find_all("tr"):
            tds = tr.find_all("td")
            if len(tds) != 2:
                continue
            key = normalize(tds[0].get_text(" ")).lower()
            if label_l == key or label_l in key:
                return normalize(tds[1].get_text(" "))

    return ""


def parse_ship_info(url: str, html: str) -> Optional[ShipInfo]:
    soup = BeautifulSoup(html, "html.parser")


    h1 = soup.find("h1")
    name = normalize(h1.get_text(" ")) if h1 else ""
    if not name and soup.title and soup.title.string:
        name = normalize(soup.title.string.split("|")[0])

    imo = _extract_value_from_tables(soup, "IMO")
    mmsi = _extract_value_from_tables(soup, "MMSI")
    ship_type = _extract_value_from_tables(soup, "Type")
    if not ship_type:
        ship_type = _extract_value_from_tables(soup, "Тип")


    text = normalize(soup.get_text(" "))
    if not imo:
        m = re.search(r"\bIMO\b\s*[:#]?\s*(\d{7})\b", text)
        if m:
            imo = m.group(1)
    if not mmsi:
        m = re.search(r"\bMMSI\b\s*[:#]?\s*(\d{9})\b", text)
        if m:
            mmsi = m.group(1)
    if not ship_type:
        m = re.search(r"\bType\b\s*[:#]?\s*([A-Za-z0-9 \-/]{2,60})", text)
        if m:
            ship_type = normalize(m.group(1))

    if not (name and imo and mmsi):
        return None

    return ShipInfo(
        link=url,
        name=name,
        imo=imo,
        mmsi=mmsi,
        ship_type=ship_type,
    )




def process_link(link: str, timeout: int, delay: float) -> Tuple[Optional[ShipInfo], str]:
    try:
        final_url, html = fetch(link, timeout)
    except Exception as e:
        return None, f"Ошибка загрузки: {e}"

    if delay > 0:
        time.sleep(delay)


    if is_vessel_page(html):
        info = parse_ship_info(final_url, html)
        if info:
            return info, ""
        return None, "Страница судна, но данные не извлечены"


    vessel_links = extract_vessel_links_from_search(html)

    if len(vessel_links) != 1:
        return None, f"В поиске найдено судов: {len(vessel_links)}"

    try:
        vessel_url, vessel_html = fetch(vessel_links[0], timeout)
    except Exception as e:
        return None, f"Ошибка загрузки страницы судна: {e}"

    if delay > 0:
        time.sleep(delay)

    info = parse_ship_info(vessel_url, vessel_html)
    if info:
        return info, ""

    return None, "Ровно 1 судно, но данные не извлечены"




def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="Links.xlsx", help="Excel файл со ссылками")
    parser.add_argument("--output", default="result.xlsx", help="Выходной Excel файл")
    parser.add_argument("--timeout", type=int, default=20)
    parser.add_argument("--delay", type=float, default=0.4)
    args = parser.parse_args()

    df = pd.read_excel(args.input)

    if "Ссылка" in df.columns:
        links = df["Ссылка"].dropna().astype(str).tolist()
    else:
        links = df.iloc[:, 0].dropna().astype(str).tolist()

    results: List[Dict[str, str]] = []
    skipped: List[Dict[str, str]] = []

    for i, link in enumerate(links, 1):
        link = link.strip()
        if not link:
            continue

        info, reason = process_link(link, args.timeout, args.delay)

        if info:
            results.append({
                "Ссылка": info.link,
                "Название": info.name,
                "IMO": info.imo,
                "MMSI": info.mmsi,
                "Тип": info.ship_type,
            })
            print(f"[{i}/{len(links)}] OK: {info.name}")
        else:
            skipped.append({"Ссылка": link, "Причина": reason})
            print(f"[{i}/{len(links)}] SKIP: {reason} :: {link}")

    with pd.ExcelWriter(args.output, engine="openpyxl") as writer:
        pd.DataFrame(results).to_excel(writer, index=False, sheet_name="Result")
        pd.DataFrame(skipped).to_excel(writer, index=False, sheet_name="Skipped")

    print(f"\nГотово. Найдено: {len(results)} | Пропущено: {len(skipped)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
