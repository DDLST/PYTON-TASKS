from input_handlers import manual_input, read_csv_file, read_json_file
from validation import validate_table_name, validate_columns, validate_rows
from kafka_sender import send_message


def process_single_table():
    print("\nВыберите способ ввода данных:")
    print("1 - Ручной ввод")
    print("2 - Загрузка CSV файла")
    print("3 - Загрузка JSON файла")

    choice = input("> ").strip()

    if choice == "1":
        table_name, columns, rows = manual_input()

    elif choice == "2":
        csv_path = input("Введите путь к CSV файлу: ").strip()
        table_name = input("Введите имя таблицы: ").strip()
        columns, rows = read_csv_file(csv_path)

    elif choice == "3":
        json_path = input("Введите путь к JSON файлу: ").strip()
        table_name, columns, rows = read_json_file(json_path)

    else:
        print("Неверный выбор режима")
        return

    validate_table_name(table_name)
    columns = validate_columns(columns)
    validate_rows(rows, len(columns))

    message = {
        "table_name": table_name,
        "columns": columns,
        "rows": rows
    }

    send_message(message)
    print(f"Данные для таблицы '{table_name}' успешно отправлены в Kafka")


def main():
    print("ETL Producer (Kafka)")

    while True:
        try:
            process_single_table()
        except Exception as error:
            print("Ошибка:", error)

        answer = input("\nДобавить ещё одну таблицу? (y/n): ").lower()
        if answer != "y":
            break

    print("Работа Producer завершена")


if __name__ == "__main__":
    main()
