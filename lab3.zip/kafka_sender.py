import json
from config import KAFKA_BOOTSTRAP_SERVERS, KAFKA_TOPIC

# Закомментируем подключение к реальной Kafka
# _producer = None
# def get_producer():
#     global _producer
#     if _producer is None:
#         _producer = KafkaProducer(
#             bootstrap_servers=KAFKA_BOOTSTRAP_SERVERS,
#             value_serializer=lambda value: json.dumps(value).encode("utf-8")
#         )
#     return _producer

# Подмена функции send_message для тестирования
def send_message(message: dict):
    print("\nСообщение, которое отправилось бы в Kafka")
    print(json.dumps(message, indent=2))
    print(" Конец сообщения \n")
