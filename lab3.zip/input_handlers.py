import csv
import json


def manual_input():
    table_name = input("Введите имя таблицы: ").strip()

    columns = input("Введите названия столбцов через запятую: ").split(",")

    rows = []
    print(
        "Введите строки данных:\n"
        " - '///' — разделитель столбцов\n"
        " - пустая строка — завершить ввод"
    )

    while True:
        line = input()
        if not line:
            break
        rows.append([value.strip() for value in line.split("///")])

    return table_name, columns, rows


def read_csv_file(path: str):
    """
    CSV формат:
    1 строка — столбцы
    остальные — данные
    имя таблицы НЕ задаётся
    """
    with open(path, newline="", encoding="utf-8") as file:
        reader = csv.reader(file)
        data = list(reader)

    if len(data) < 2:
        raise ValueError("CSV файл пуст или не содержит данных")

    columns = data[0]
    rows = data[1:]

    table_name = None 
    return table_name, columns, rows


def read_json_file(path: str):
    """
    JSON может содержать table_name, а может и нет
    """
    with open(path, encoding="utf-8") as file:
        data = json.load(file)

    if "columns" not in data or "rows" not in data:
        raise ValueError("JSON файл имеет неверную структуру")

    table_name = data.get("table_name")  
    return table_name, data["columns"], data["rows"]
