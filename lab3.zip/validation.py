import re


def validate_table_name(name: str):
    if not name:
        raise ValueError("Имя таблицы не может быть пустым")

    if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", name):
        raise ValueError("Некорректное имя таблицы")


def validate_columns(columns: list[str]) -> list[str]:
    if not columns:
        raise ValueError("Список столбцов пуст")

    cleaned_columns = []
    for column in columns:
        column = column.strip()
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", column):
            raise ValueError(f"Некорректное имя столбца: {column}")
        cleaned_columns.append(column)

    if len(cleaned_columns) != len(set(cleaned_columns)):
        raise ValueError("Названия столбцов должны быть уникальны")

    return cleaned_columns


def validate_rows(rows: list[list], columns_count: int):
    if not rows:
        raise ValueError("Отсутствуют данные для вставки")

    for index, row in enumerate(rows):
        if len(row) != columns_count:
            raise ValueError(
                f"Ошибка в строке {index + 1}: "
                f"ожидалось {columns_count} значений, получено {len(row)}"
            )
